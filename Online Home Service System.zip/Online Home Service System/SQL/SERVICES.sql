#SERVICES TABLE

#CREATE TABLE

CREATE TABLE SERVICES (
SERVICE_ID integer (5) NOT NULL,
PRIMARY KEY (SERVICE_ID),
SERVICE_NAME VARCHAR(300),
SERVICE_DESCRIPTION VARCHAR(500)
);
describe SERVICES;
#ALTER QUERY

ALTER TABLE SERVICES MODIFY SERVICE_ID VARCHAR(5);
ALTER TABLE SERVICES MODIFY SERVICE_DESCRIPTION VARCHAR(2000);

#INSERT QUERY 

INSERT INTO SERVICES (SERVICE_ID, SERVICE_NAME, SERVICE_DESCRIPTION ) VALUES ('SER01', ' Salon Services' , ' Cleanups & Facials, Bleach and Detan, Manicure, Pedicure, Hair Services, Makeup Services, Massage Services' );

INSERT INTO SERVICES (SERVICE_ID, SERVICE_NAME, SERVICE_DESCRIPTION ) VALUES ('SER02', ' Electricians' , ' For Repairing Switch and Socket, Fans, Lights, MCB and Fuse, Inverters and Stabilizers, Appliance, Wiring, etc' );

INSERT INTO SERVICES (SERVICE_ID, SERVICE_NAME, SERVICE_DESCRIPTION ) VALUES ('SER03', ' Plumbers' , ' For Repairing basin & sink, Bath fitting, Blockage, Top & Mixer, Water tank, Motor, Minor Installation etc' );

INSERT INTO SERVICES (SERVICE_ID, SERVICE_NAME, SERVICE_DESCRIPTION ) VALUES ('SER04', ' House Painting' , ' For few houses, few rooms, few walls, wallpapers, etc' );

INSERT INTO SERVICES (SERVICE_ID, SERVICE_NAME, SERVICE_DESCRIPTION ) VALUES ('SER05', ' Appliance Repair' , 'AC, Washing Machine, Geyser, RO or Water purifier, Refridgerator, Microwave, TV Service and Repair' );

INSERT INTO SERVICES (SERVICE_ID, SERVICE_NAME, SERVICE_DESCRIPTION ) VALUES 
('SER06', ' Cleaning & Pest Control' , ' Bathroom Cleaning, Sofa Cleaning, Kitchen Deep Cleaning, Carpet Cleaning, Full Home cleaning, Car Cleaning, Pest Control' );

INSERT INTO SERVICES (SERVICE_ID, SERVICE_NAME, SERVICE_DESCRIPTION ) VALUES ('SER07', ' Party Planning & Decoration' , ' Party Planning & Decoration' );

INSERT INTO SERVICES (SERVICE_ID, SERVICE_NAME, SERVICE_DESCRIPTION ) VALUES ('SER08', ' Yoga Trainer' , ' Fitness Guidance, Yoga Traning, Meditation, Detox & Rejuvenation' );

INSERT INTO SERVICES (SERVICE_ID, SERVICE_NAME, SERVICE_DESCRIPTION ) VALUES ('SER09', ' Interior Designer' , 'Consultation, furnishings, Lighting, Accessories' );

INSERT INTO SERVICES (SERVICE_ID, SERVICE_NAME, SERVICE_DESCRIPTION ) VALUES 
('SER10', ' Wedding Photographer' , ' Destination Photography, Pre Wedding Photography, Traditional Photography, Candid Photography, Videography, Cinematography' );




#SELECT QUERY

SELECT *FROM SERVICES;

#COMMIT QUERY

COMMIT;
