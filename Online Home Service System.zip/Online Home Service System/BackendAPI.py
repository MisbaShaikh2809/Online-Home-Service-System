from flask import Flask,render_template,url_for,redirect,request
import mysql.connector as con


db=con.connect(host="localhost",user="root",passwd="@Pass123",database="project",auth_plugin='mysql_native_password')
csr=db.cursor()




app = Flask(__name__)

@app.route("/",methods=['GET','POST'])
def Login():
    if request.method=="POST":
        post_data=request.form
        username=post_data["Username"]
        pwd=post_data["Pass"]
        if username=="student"and pwd=="1234":
            return redirect(url_for('Home'))

    return render_template('Login.html')
    
@app.route("/HOME",methods=['GET','POST'])
def Home():
    return render_template('homepage.html')

@app.route("/insertservice",methods=['GET','POST'])
def insertservice():
    if request.method=="POST":
        post_data=request.form
        s_id=post_data["SERVICE_ID"]
        s_name=post_data["SERVICE_NAME"]
        s_dec=post_data["SERVICE_DESCRIPTION"]
        query=f"INSERT INTO SERVICES (SERVICE_ID, SERVICE_NAME, SERVICE_DESCRIPTION ) VALUES ('{s_id}','{s_name}','{s_dec}')"
        csr.execute(query)
        db.commit()
    return render_template('insertservice.html')

@app.route("/insertstaff",methods=['GET','POST'])
def insertstaff():
    if request.method=="POST":
        post_data=request.form
        id=post_data["REG_ID"]
        name=post_data["FULL_NAME"]
        contact=post_data["CONTACT_NO"]
        email=post_data["EMAIL_ID"]
        age=post_data["AGE"]
        cat=post_data["SERVICE_CATEGORY"]
        qual=post_data["QUALIFICATION"]
        address=post_data["RES_ADDRESS"]
        query=f"INSERT INTO REGISTRATION (REG_ID, FULL_NAME, CONTACT_NO,  EMAIL_ID, AGE, SERVICE_CATEGORY, QUALIFICATION, RES_ADDRESS) VALUES('{id}', '{name}', '{contact}', '{email}', '{age}', '{cat}', '{qual}', '{address}')"
        csr.execute(query)
        db.commit()
    return render_template('insertstaff.html')

@app.route("/insertuser",methods=['GET','POST'])
def insertuser():
    if request.method=="POST":
        post_data=request.form
        id=post_data["REG_ID"]
        name=post_data["FULL_NAME"]
        contact=post_data["CONTACT_NO"]
        email=post_data["EMAIL_ID"]
        age=post_data["AGE"]
        address=post_data["RES_ADDRESS"]
        query=f"INSERT INTO  USER_DETAILS (REG_ID, FULL_NAME, CONTACT_NO, EMAIL_ID,RES_ADDRESS, AGE) VALUES ('{id}', '{name}', '{contact}', '{email}', '{address}','{age}')"
        csr.execute(query)
        db.commit()
    return render_template('insertuser.html')

@app.route("/updateservice",methods=['GET','POST'])
def updateservice():
    if request.method=="POST":
        post_data=request.form
        s_id=post_data["SERVICE_ID"]
        s_name=post_data["SERVICE_NAME"]
        s_dec=post_data["SERVICE_DESCRIPTION"]
        query=f"UPDATE SERVICES SET SERVICE_NAME='{s_name}',SERVICE_DESCRIPTION='{s_dec}' WHERE SERVICE_ID='{s_id}'"
        csr.execute(query)
        db.commit()
    return render_template('updateservice.html')

@app.route("/updatestaff",methods=['GET','POST'])
def updatestaff():
    if request.method=="POST":
        post_data=request.form
        id=post_data["REG_ID"]
        name=post_data["FULL_NAME"]
        contact=post_data["CONTACT_NO"]
        email=post_data["EMAIL_ID"]
        age=post_data["AGE"]
        cat=post_data["SERVICE_CATEGORY"]
        qual=post_data["QUALIFICATION"]
        address=post_data["RES_ADDRESS"]
        query=f"UPDATE REGISTRATION SET FULL_NAME='{name}',CONTACT_NO='{contact}',EMAIL_ID='{email}', AGE='{age}', SERVICE_CATEGORY='{cat}', QUALIFICATION='{qual}', RES_ADDRESS='{address}' WHERE REG_ID='{id}' "
        csr.execute(query)
        db.commit()
    return render_template('updatestaff.html')

@app.route("/updateuser",methods=['GET','POST'])
def updateuser():
    if request.method=="POST":
        post_data=request.form
        id=post_data["REG_ID"]
        name=post_data["FULL_NAME"]
        contact=post_data["CONTACT_NO"]
        email=post_data["EMAIL_ID"]
        age=post_data["AGE"]
        address=post_data["RES_ADDRESS"]
        query=f"UPDATE USER_DETAILS SET FULL_NAME='{name}',CONTACT_NO='{contact}',EMAIL_ID='{email}', AGE='{age}', RES_ADDRESS='{address}' WHERE REG_ID='{id}' "
        csr.execute(query)
        db.commit()
    return render_template('updateuser.html')

@app.route("/deleteservice",methods=['GET','POST'])
def deleteservice():
    if request.method=="POST":
        post_data=request.form
        s_id=post_data["SERVICE_ID"]
        query=f"DELETE FROM SERVICES WHERE SERVICE_ID='{s_id}'"
        csr.execute(query)
        db.commit()
    return render_template('deleteservice.html')

@app.route("/showdetails",methods=['GET','POST'])
def showdetails():
    if request.method=="POST":
        post_data=request.form
        show_table=post_data["category"]
        query=f"SELECT * FROM {show_table}"
        csr.execute(query)
        fetch_data=csr.fetchall()
        return render_template('showtable.html',data=fetch_data,table=show_table)

    return render_template('showdetails.html')

if __name__ == "__main__":
        app.run(debug=True)