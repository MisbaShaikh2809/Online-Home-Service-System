
	function myFunction()
	{

		var un = document.getElementById("Uname").value; 
		var pw = document.getElementById("Pass").value; 
		if(un=="student" && pw=="1234")
		{	
			alert("Login Successfully!");
			return false;
		}
		else
		{
			alert("Invalid UserName and Password!");
		}
 
	} 
